# Report Week 5

## What was done

### Mechanical 

- Safety training completed (Jakob Paul)

### Documentation

- Setup mkdocs
- refactored and cleared up some docs


### ROS2

- Further advancements in name space issue
    - new remapping syntax fixes the problem with the underlaying nodes
    - Refactored all our nodes to not explicitly use namespaces
- Succesfully sent navigation goals through ros2 nodes with new changes implemented
- Figured out why the robots were sucidial 
- Discussed node architecture
- Implemented master node
    - Battery moinitoring and dock turtlebots if battery drops below threshold
- Started parameterization of our system


### Networking

- Tried to set up a turtlebot in discovery server mode instead of simple discovery.
    - It seems the create 3 platform is not performing as expected after the firmware update
    - The Correct setup of the discovery server mode still has to be found
- Adressed the issue that the turtlebot kept getting kicked out of the network
    - It seems that for the mci_teaching03 and mci_teaching04 networks, the turtlebot will only be stable in the network, when connected to the 2.4 GHz Wifi,
          even though the official documentation does not recommend this
    - The turtlebot4 is stable in the 5 GHz Wifi in the ZentrumPRA Wifi
    - The current assumption is, that the 5 GHz Wifi of the mci_teaching Networks may be set up with frequencies/bands that are compatible with the RasPi's Wifi         chip
    - A deeper look into the Wifi setup is still needed, but there is now a way to put the turtlebots into a Wifi that is also connected to the internet
- Tried a simple navigation working example in the mci_teaching03 network with robot5 -> worked, Internet is also accessible
  
   
