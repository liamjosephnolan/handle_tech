# Report Week 1

## What was done

### Mechanical 

- Discussion about the vertical delta for the elevator
- Timeline for designing and manifacturing

### Documentation

- Researching appropriate tools
- Setting up documentation structure
- Discussion about the best way to integrate the repo into the ros2 workspace

### ROS2

- Trying to set up router 
    - Network issues