# Report Week 2

## What was done

### Mechanical 

- Waiting for laser cutter access to begin manufacturing

### Documentation

- Established Github protocool for our ROS2_ws
- Will be working mostly in python but have seperate package for C++

### ROS2

- Setup overall node structure
- Working on RVIS node
  - Running into issues with namespace
  - Have found a work around but need to test
  - Documentation contained in RVIZ walkthrough
- Working through undocking issue
  - Turtlebots will undock upon boot and die
  - Estop trigger will prevent Rviz Movement


### Networking
- Setup new router
- Trying to move the robots to new network
  #### we tryed to: 
    - Made the adresses static in the router
    - Shorted the DHCP range to not interfer with the turtlebot ips in the future
    - Changed the wifi setup of the turtlebots to also represent the static ip 
#### Problems occured: 
    - static IP setting did not work and turtlebot was 'lost'
    - disconnectin of the turtlebot from the router after a few seconds (tryout with ping)
#### Solving options: 
    - manual resetting to ZentrumPRA wifi via ethernet connection to turtlebot controller
    - tryout of another router (not yet successfull) -> further clarification with IT
