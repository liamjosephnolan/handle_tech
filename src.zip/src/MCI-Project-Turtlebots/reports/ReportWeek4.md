# Report Week 4

## What was done

### Mechanical 

- Updated the factory angle from 5deg to 7.5deg
- Angle change only required update of two parts

### Documentation



### ROS2

- Figured out name space issue
    - Implimented the fix through a fork of the turtlebot4 repo and building it localy
    - Opened PR for the changes on the turtlebot4 repo
    - PR got accepted, the package version for humble seems to be froozen, therefore we still need the fork or build from the offical source
    - Further investigation will be done over the weekend
- Succesfully sent navigation goals through ros2 nodes
- Figured out calling estop service to stop sucidial robots


### Networking
- After IT appointment: No status change from IT side, acoording to IT the network issue. Last weeks issues should have been caused by plugging in the ASUS router (black-listed)
- Tried again to move one turtlebot to the mciteaching03 network
- Found out that not only turtlebot raspberry PI but also turtlebot base needs to be connected to the new router (before both were on the ASUS router)
- The network connecection is still not stable and disconnects after some minutes with robot90 (test dummy) (test was done by pining the turtlebot RaspberryPI) -> solution could be to separate the network into 5GHz and 2.4GHz as the base needs 2.4GHz connection
- Created a second SSID for 2.4GHz, Connection with was not yet possible as the PI got kicked out faster from the network, as change of the board was possible. Solution for the next week is to change the base wifi static with a Ethernet connection.
- Research about changing the setting to Discovery Sever instead of Simple Discovery, as this is reducing the network traffic when using mupltipe robots.
