# Report Week 6

## What was done

### Mechanical 
- Design was completely redone
- CAD spin
- Order list updated, suppliers are asked for offers accodring to MCI oder standard
- first orders done from Daniel (missing: acrylic glass, parts from Amazon) - waiting for reply about order procedure

### ROS2
- Aurco Camera code working
- figured out how the lift works. To be solved how to control it without being ssh into the robot 

### Tests
- Prepared a first Demo of a turtlebot running to and from a station - docking at the loading an unloading site.

