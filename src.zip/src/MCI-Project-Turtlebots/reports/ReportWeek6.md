# Report Week 6

## What was done

### Mechanical 
- checked reconstruction for turtlebots 
- defined parts which needed to be modified in the CAD to use part of existing set up
- created a order list
- redesign of the CAD after discusssion with B. Massow

### Documentation

- refined docs
- installed docs theme
- added architecture docs
    - draft graphs for communication
    - current rqt graph


### ROS2
- Architecture additions
    - State Machine
    - Offer/Response system for dispatching the robots for the tasks

- Turtle State Machine 
    - Logic for charging if low battery
    - Logic for docking
    - Future addtions for the offer system should be easily possible

- Parameterized all nodes they now share robots.yaml
    - Factory Positions, Robots list and dock positions
    - Easy additions possible in the future

- Some clear up and refactoring
- Code walkthrough with theteam


### Networking
- decision to contiunes on the ASUS router as this is the only stable option to operate

  
   
