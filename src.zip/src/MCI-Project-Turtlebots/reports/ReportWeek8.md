# Report Week 6

## What was done

### Mechanical 
- first parts ordered by from Daniel (missing: acrylic glass, parts from Amazon) - waiting for reply about order procedure

### ROS2
- further working on the lift code - the elevator can be driven to position
- Working on allowing elevator script to be launched from turtlebot4 menu
- working on making the procedures more robust

