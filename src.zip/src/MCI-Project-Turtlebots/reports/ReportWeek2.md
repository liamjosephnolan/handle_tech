# Report Week 2

## What was done

### Mechanical 

- Further Discussion about the vertical delta for the elevator
- Took more Meassurements and advanced the design
    - Should be possible to adjust the angle of the factory using the given vertical delta
    - and reusing a lot of the hardware (and design) from the elevators

### Documentation

- Documented everything that wasnt clear yet in the given docs
    - RVIS Workthrough

### ROS2

- Mainly RVIS
    - getting RVIS to work again
    - Started to look into sending RVIS Goals from a node
    - Started to look into aruco codes to build our understanding of how we handle all the navigation with the different concepts