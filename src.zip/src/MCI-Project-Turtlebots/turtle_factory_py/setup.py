from setuptools import find_packages, setup
import os 
from glob import glob

package_name = 'turtle_factory_py'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name, ['launch/mci_launch.launch.py']),
        ('share/' + package_name, ['config/robots.yml']),
        ('share/' + package_name, ['config/nav2_params.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='liam',
    maintainer_email='liamjosephnolan@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
                'turt_nav_node = turtle_factory_py.turt_nav_node:main',
                'master_dispatcher_node = turtle_factory_py.master_dispatcher_node:main',
                'master_dispatcher_test_node = turtle_factory_py.master_dispatcher_test_node:main',
                'turt_nav_test_node = turtle_factory_py.turt_nav_test_node:main',
                'turt_state_machine = turtle_factory_py.turt_state_machine:main',
                'turt_camera_test_node = turtle_factory_py.turt_camera_test_node:main',
                'elevator_node = turtle_factory_py.elevator_node:main',
            ],
    },
)
