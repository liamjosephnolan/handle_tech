#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import cv2.aruco as aruco
import numpy as np

class ArucoFollower(Node):
    def __init__(self):
        super().__init__('aruco_follower')
        
        # Initialize CV Bridge
        self.bridge = CvBridge()
        
        # Subscribe to the image topic
        self.subscription = self.create_subscription(
            Image,
            '/oakd/rgb/preview/image_raw',
            self.image_callback,
            10)
        
        # Publisher for robot velocity commands
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # ArUco dictionary and parameters
        self.aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_5X5_250)
        self.aruco_params = aruco.DetectorParameters()
        
        # Camera calibration parameters (needs to be calibrated for your camera)
        self.camera_matrix = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]], dtype=np.float32)
        self.dist_coeffs = np.zeros((4, 1))  # Assuming no lens distortion
        
        # Marker size in meters (1m square)
        self.marker_size = 1.0
        
    def image_callback(self, msg):
        try:
            # Convert ROS Image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            self.get_logger().error(f'Error converting image: {e}')
            return
        
        # Detect ArUco markers
        corners, ids, _ = aruco.detectMarkers(cv_image, self.aruco_dict, parameters=self.aruco_params)
        
        if ids is not None:
            # Estimate pose of each detected marker
            rvecs, tvecs, _ = aruco.estimatePoseSingleMarkers(corners, self.marker_size, self.camera_matrix, self.dist_coeffs)
            
            for i in range(len(ids)):
                # Draw the detected marker and its axis
                cv_image = aruco.drawDetectedMarkers(cv_image, corners, ids)
                cv_image = cv2.drawFrameAxes(cv_image, self.camera_matrix, self.dist_coeffs, rvecs[i], tvecs[i], 0.5)
                
                # Get the translation vector (distance to the marker)
                tvec = tvecs[i][0]
                distance = np.linalg.norm(tvec)
                
                # Log the distance and pose
                self.get_logger().info(f'Detected marker {ids[i][0]} at distance: {distance:.2f} meters')
                
                # Drive towards the marker
                self.drive_towards_marker(tvec)
        
        # Display the image with detected markers
        cv2.imshow('ArUco Detection', cv_image)
        cv2.waitKey(1)
    
    def drive_towards_marker(self, tvec):
        # Create a Twist message to control the robot
        twist = Twist()
        
        # Proportional control constants
        linear_kp = 0.5
        angular_kp = 1.0
        
        # Calculate errors
        x_error = tvec[0]  # Lateral error
        z_error = tvec[2]  # Forward error
        
        # Control the robot's linear and angular velocity
        twist.linear.x = linear_kp * z_error
        twist.angular.z = -angular_kp * x_error
        
        # Publish the Twist message
        self.publisher.publish(twist)
    
    def destroy_node(self):
        # Stop the robot when the node is destroyed
        twist = Twist()
        self.publisher.publish(twist)
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    aruco_follower = ArucoFollower()
    rclpy.spin(aruco_follower)
    aruco_follower.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
