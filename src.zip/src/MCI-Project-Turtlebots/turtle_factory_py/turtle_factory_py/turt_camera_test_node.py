import rclpy  # Python library for ROS 2
from rclpy.node import Node
from cv_bridge import CvBridge
from geometry_msgs.msg import TransformStamped, PointStamped
from sensor_msgs.msg import Image
from tf2_ros import TransformBroadcaster, Buffer, TransformListener
import cv2
import numpy as np
from scipy.spatial.transform import Rotation as R

# The different ArUco dictionaries built into the OpenCV library.
ARUCO_DICT = {
    "DICT_5X5_250": cv2.aruco.DICT_5X5_250
}

class ArucoNode(Node):
    def __init__(self):
        """
        Class constructor to set up the node
        """
        super().__init__('aruco_node')

        # Declare parameters
        self.declare_parameter("aruco_dictionary_name", "DICT_5X5_250")
        self.declare_parameter("aruco_marker_side_length", 0.25)  # 25 cm marker size
        self.declare_parameter("image_topic", "/oakd/rgb/preview/image_raw")
        self.declare_parameter("aruco_marker_name", "aruco_marker")

        # Read parameters
        aruco_dictionary_name = self.get_parameter("aruco_dictionary_name").get_parameter_value().string_value
        self.aruco_marker_side_length = self.get_parameter("aruco_marker_side_length").get_parameter_value().double_value
        image_topic = self.get_parameter("image_topic").get_parameter_value().string_value
        self.aruco_marker_name = self.get_parameter("aruco_marker_name").get_parameter_value().string_value

        # Check that we have a valid ArUco marker
        if ARUCO_DICT.get(aruco_dictionary_name, None) is None:
            self.get_logger().info("[ERROR] ArUCo dictionary '{}' is not supported.".format(aruco_dictionary_name))
            return

        # Hardcoded Camera Calibration Parameters (from /oakd/rgb/preview/camera_info)
        self.mtx = np.array([[277.0, 0.0, 160.0], 
                             [0.0, 277.0, 120.0], 
                             [0.0, 0.0, 1.0]])

        self.dst = np.array([0.0, 0.0, 0.0, 0.0, 0.0])  # No distortion

        # Load the ArUco dictionary
        self.this_aruco_dictionary = cv2.aruco.getPredefinedDictionary(ARUCO_DICT[aruco_dictionary_name])
        self.this_aruco_parameters = cv2.aruco.DetectorParameters()

        # Create the subscriber for the camera images
        self.subscription = self.create_subscription(
            Image,
            image_topic,
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning

        # Initialize the transform broadcaster and listener
        self.tfbroadcaster = TransformBroadcaster(self)
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Used to convert between ROS and OpenCV images
        self.bridge = CvBridge()

    def listener_callback(self, data):
        """
        Callback function.
        """
        self.get_logger().info('Receiving video frame')

        # Convert ROS Image message to OpenCV image
        current_frame = self.bridge.imgmsg_to_cv2(data)

        # Detect ArUco markers in the video frame
        corners, marker_ids, _ = cv2.aruco.detectMarkers(
            current_frame, self.this_aruco_dictionary, parameters=self.this_aruco_parameters)

        # Check that at least one ArUco marker was detected
        if marker_ids is not None:
            # Draw a square around detected markers in the video frame
            cv2.aruco.drawDetectedMarkers(current_frame, corners, marker_ids)

            # Get the rotation and translation vectors
            rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(
                corners, self.aruco_marker_side_length, self.mtx, self.dst)

            # Iterate through detected markers
            for i, marker_id in enumerate(marker_ids):
                # Create the coordinate transform for the marker in camera frame
                t = TransformStamped()
                t.header.stamp = self.get_clock().now().to_msg()
                t.header.frame_id = 'oakd_rgb_camera_optical_frame'
                t.child_frame_id = self.aruco_marker_name

                # Store the translation (position) information in camera frame
                t.transform.translation.x = tvecs[i][0][0]
                t.transform.translation.y = tvecs[i][0][1]
                t.transform.translation.z = tvecs[i][0][2]

                # Store the rotation information in quaternion format
                rotation_matrix = np.eye(4)
                rotation_matrix[0:3, 0:3] = cv2.Rodrigues(np.array(rvecs[i][0]))[0]
                r = R.from_matrix(rotation_matrix[0:3, 0:3])
                quat = r.as_quat()
                t.transform.rotation.x = quat[0]
                t.transform.rotation.y = quat[1]
                t.transform.rotation.z = quat[2]
                t.transform.rotation.w = quat[3]

                # Send the transform from the camera frame to the marker's frame
                self.tfbroadcaster.sendTransform(t)

                # Transform the marker's pose from camera frame to map frame
                try:
                    # Transform the marker's position from the camera frame to the map frame
                    transform = self.tf_buffer.lookup_transform('map', 'oakd_rgb_camera_optical_frame', rclpy.time.Time())
                    transformed_t = self.transform_point(tvecs[i], transform)
                    
                    # Log the transformed position (in map frame)
                    self.get_logger().info(f"Transformed Marker {marker_id[0]} position in map frame: "
                                           f"X={transformed_t.x}, Y={transformed_t.y}, Z={transformed_t.z}")

                except Exception as e:
                    self.get_logger().info(f"Error: {e}")

                # Draw the axes on the marker using the alternative method
                cv2.drawFrameAxes(current_frame, self.mtx, self.dst, rvecs[i], tvecs[i], 0.05)

        # Display image
        cv2.imshow("camera", current_frame)
        cv2.waitKey(1)

    def transform_point(self, tvec, transform):
        """
        Transform the marker's position from camera frame to map frame.
        """
        # Create a PointStamped message for the marker position in the camera frame
        point = PointStamped()
        point.header.stamp = self.get_clock().now().to_msg()
        point.header.frame_id = 'oakd_rgb_camera_optical_frame'
        point.point.x = tvec[0][0]
        point.point.y = tvec[0][1]
        point.point.z = tvec[0][2]

        # Transform the point to the map frame
        transformed_point = self.tf_buffer.transform(point, 'map')
        return transformed_point.point


def main(args=None):
    # Initialize the rclpy library
    rclpy.init(args=args)

    # Create the node
    aruco_node = ArucoNode()

    # Spin the node so the callback function is called.
    rclpy.spin(aruco_node)

    # Destroy the node explicitly (optional)
    aruco_node.destroy_node()

    # Shutdown the ROS client library for Python
    rclpy.shutdown()


if __name__ == '__main__':
    main()
