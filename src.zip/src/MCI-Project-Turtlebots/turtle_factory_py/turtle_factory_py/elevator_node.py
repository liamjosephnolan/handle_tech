import rclpy
from rclpy.action import ActionServer
from rclpy.node import Node

import gpiod
import math
import time

import datetime

from interfaces_mci.action import Elevator

class ElevatorActionNode(Node):
    # pinout
    STEP_PIN = 9
    DIR_PIN = 10
    STOP_PIN = 11
    ENABLE_PIN = 12

    # stepper settings/geometry
    DIRECTION = 1 # -1 to invert direction
    MICROSTEPPING = 8
    MM_PER_REV = 8
    STEP_ANGLE = 1.8 # degrees

    # actuation limits
    Z_AXIS_LOWER_LIMIT = 0 # mm
    Z_AXIS_UPPER_LIMIT = 150 # mm

    # acc and velo
    VELOCITY = 2 # in rad/s
    ACCELERATION = 2 # in rad/s

    def __init__(self):
        super().__init__('elevator_action_server')
        self.get_namespace()
        self._action_server = ActionServer(
            self,
            Elevator,
            'drive_elevator',
            self.execute_callback)

        self.zPos = 0
        self.enableEndstop = False

    def execute_callback(self, goal_handle):
        self.get_logger().info('Executing goal...')
        feedback_msg = Elevator.Feedback()
        result = Elevator.Result()

        while self.init_gpio() != 0:
            self.get_logger().info("Try to init_gpio")

        position = goal_handle.request.position

        if(self.moveElevator(position)):
            feedback_msg.actual_position = self.zPos
            result.position_reached = True
            goal_handle.publish_feedback(feedback_msg)
            goal_handle.succeed()
            return result
        else:
            feedback_msg.actual_position = self.zPos
            result.position_reached = False
            goal_handle.publish_feedback(feedback_msg)
            goal_handle.aborted() 
            return result    

    def init_gpio(self):
        try:
            self.chip = gpiod.chip('/dev/gpiochip0')
            self.line_step = self.chip.get_line(self.STEP_PIN)
            self.line_dir = self.chip.get_line(self.DIR_PIN)
            self.line_enable = self.chip.get_line(self.ENABLE_PIN)
            self.line_stop = self.chip.get_line(self.STOP_PIN)

            OUTconfig = gpiod.line_request()
            OUTconfig.consumer = "stepper"
            OUTconfig.request_type = gpiod.line_request.DIRECTION_OUTPUT

            INconfig = gpiod.line_request()
            INconfig.consumer = "endStop"
            INconfig.request_type = gpiod.line_request.DIRECTION_INPUT

            self.line_step.request(OUTconfig)
            self.line_dir.request(OUTconfig)
            self.line_enable.request(OUTconfig)
            self.line_stop.request(INconfig)
            return 0

        except:
            return -1

    def homeElevator(self):
        self.enableElevator()

        while self.line_stop.get_value() == 0:
            self.get_logger().info("error: Check homing endstop...")
            time.sleep(1)

        self.get_logger().info("Elevator homing...")
        self.enableEndstop = True
        self.moveTo(-self.Z_AXIS_UPPER_LIMIT,5,5)
        self.zPos = 0
        self.moveTo(3, 5, 5)
        self.enableEndstop = False

        self.get_logger().info("Elevator homing complete...")
        self.disableElevator()

    def enableElevator(self):
        self.line_enable.set_value(0)

    def disableElevator(self): 
        self.line_enable.set_value(1)

    def moveElevator(self, position):
        self.enableElevator()

        #SAFETY_FEATURE
        if(position > self.Z_AXIS_UPPER_LIMIT or position < self.Z_AXIS_LOWER_LIMIT):
            self.get_logger().info(f"Requested motion exceeds axis limits - min: {self.Z_AXIS_LOWER_LIMIT}, max: {self.Z_AXIS_UPPER_LIMIT}")
            return False

        if(position == 0):
            self.moveTo(5, self.VELOCITY, self.ACCELERATION)
            self.homeElevator()

        else:
            self.moveTo(position, self.VELOCITY, self.ACCELERATION)

        self.zPos = position

        if(self.zPos == 0):
            self.disableElevator()

        self.get_logger().info(f"Elevator motion complete: {self.zPos} mm")

        return True

    def moveTo(self, dest_point, lin_vel, lin_accel):
        steps_per_rev = 360 / self.STEP_ANGLE * self.MICROSTEPPING

        distance = dest_point - self.zPos # in mm
        stepsRequired = abs(distance * steps_per_rev / self.MM_PER_REV)

        if(distance*self.DIRECTION < 0):
            self.line_dir.set_value(1)
        else:
            self.line_dir.set_value(0)

        # compute velocity trajectory
        angle_per_step = 2 * math.pi / steps_per_rev # 1 rev = 2*pi; 2*pi/steps_per_rev = angle_per_step in rad
        maxAngularVel = (lin_vel / self.MM_PER_REV)  * 2 * math.pi # mm/s to rev/s to rad/s
        angularAccel = (lin_accel / self.MM_PER_REV) * 2 * math.pi # mm/s^2 to rev/s^2 to rad/s^2

        maxInterval = 1 / (steps_per_rev * maxAngularVel / (2 * math.pi)) * 1000000 # *1000000 for s to us conversion
        rampUpStep = math.ceil(maxAngularVel**2 / (2 * angle_per_step * angularAccel))

        if stepsRequired / 2 < rampUpStep:
            rampUpStep = stepsRequired / 2
            rampDownStep = rampUpStep
        else:
            rampDownStep = stepsRequired - rampUpStep

        stepInterval = 0.676 * math.sqrt(2 * angle_per_step / angularAccel) * 1000000 # 1000000 for s to us conversion
        stepCounter = 0

        # set initial step timer
        stepTimer = datetime.datetime.now() + datetime.timedelta(microseconds=round(stepInterval))

        while(1):
            # if endstop is used, check state
            if self.enableEndstop:  
                if self.line_stop.get_value() == 0:
                    self.enableEndstop = False
                    return 0

            # step once
            self.line_step.set_value(1)
            self.line_step.set_value(0)
            stepCounter += 1

            # break condition
            if(stepCounter >= stepsRequired):
                break

            while(datetime.datetime.now() < stepTimer):
                pass

            # update step interval
            if stepCounter < rampUpStep:
                stepInterval -= 2*stepInterval / (4*stepCounter+1)
            elif stepCounter >= rampDownStep:
                stepInterval += 2*stepInterval / (4 * (stepsRequired-stepCounter) + 1)
            else:
                stepInterval = maxInterval

            # update timer
            stepTimer += datetime.timedelta(microseconds=round(stepInterval))


def main(args=None):
    rclpy.init(args=args)

    elevator = ElevatorActionNode()
    elevator.get_logger().info("Elevator server started ...")
    while elevator.init_gpio() != 0:
        elevator.get_logger().info("Try to init_gpio", once=True)
    elevator.homeElevator()

    rclpy.spin(elevator)


if __name__ == '__main__':
    main()
