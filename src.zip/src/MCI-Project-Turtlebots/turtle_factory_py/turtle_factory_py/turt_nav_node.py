import rclpy

from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Directions, TurtleBot4Navigator
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult

import rclpy
from rclpy.node import Node

from std_msgs.msg import String

from interfaces_mci.msg import NavMci

from irobot_create_msgs.msg import DockStatus

class TurtNavNode(Node):
    def __init__(self):
        super().__init__('turt_nav_node')
        self.subscription = self.create_subscription(
            NavMci,
            'sendNavGoalMci',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning

        self.pub = self.create_publisher(String, 'nav_goal_reached', 10)

    def listener_callback(self, msg):
        self.get_logger().info('Received nav goal! x: %f, y: %f, orientation: %d, goal_type: %s' % (msg.x, msg.y, msg.orientation, msg.goal_type))

        goal_type = msg.goal_type

        # construct TurtleBot4Navigator object
        navigator = TurtleBot4Navigator()

        goal_pose = navigator.getPoseStamped([msg.x, msg.y], msg.orientation)

        # check if robot is docked and undock if it is not
        #
        if navigator.getDockedStatus() == True:
            # if goal_type == 'dock':
                # navigator.info('Already docked!')
                # return
            navigator.info('Docked! Undocking!')
            navigator.undock()

        # wait for Nav2 stavk to fully start
        navigator.waitUntilNav2Active()

        # navigate the robbot to goal pose
        navigator.startToPose(goal_pose)

        if goal_type == 'dock':
            self.get_logger().info('Goal type dock: Docking...')
            navigator.dock()
        elif goal_type == 'park':
            self.get_logger().info('Parking robot')
        elif goal_type == 'fact':
            self.get_logger().info('Goal type fact: Docking...')
            navigator.dock()
        else:
            self.get_logger().error('Invalid goal_type: %s' % goal_type)

        # output that navigation was succesfull and then shutdown ros node
        pub_msg = String()
        pub_msg.data = 'Goal reached'
        self.pub.publish(pub_msg)
        
        navigator.info('Succesfully navigated to goal pose')


def main(args=None):
    rclpy.init(args=args)

    minimal_subscriber = TurtNavNode()

    rclpy.spin(minimal_subscriber)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_subscriber.destroy_node()
    rclpy.shutdown()
    
    
if __name__ == '__main__':
    main()