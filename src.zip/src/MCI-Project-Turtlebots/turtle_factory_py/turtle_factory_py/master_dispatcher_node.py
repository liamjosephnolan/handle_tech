import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from interfaces_mci.msg import NavMci, CostMci, NavTaskMci, NavTaskCoordsMci
import os
from ament_index_python.packages import get_package_share_directory
import yaml

class DispatcherNode(Node):
    def __init__(self):
        super().__init__('dispatcher_node')


        config = os.path.join(get_package_share_directory('turtle_factory_py'),
        'robots.yml'
        )
        self.get_logger().info(f'Loading configuration from {config}')
        
        with open(config) as file:
            self.configuration = yaml.safe_load(file)

        self.get_logger().info(f'Configuration loaded: {self.configuration}')


        self.robot_names = self.configuration['robot_list']
        self.get_logger().info(f'Robots list loaded: {self.robot_names}')
        
        self.pos_factories_lookup = {factory["name"]: factory for factory in self.configuration["pos_factories"]}
        self.get_logger().info(f'Factories list loaded: {self.pos_factories_lookup}')

        # Initialize a dictionary to store publishers for each robot
        self.robot_publishers = {}
        for robot_name in self.robot_names:
            # Create a publisher for each robot within its namespace
            topic = f'/{robot_name}/assign_objective'
            self.robot_publishers[robot_name] = self.create_publisher(NavTaskCoordsMci, topic, 10)
            self.get_logger().info(f'Publisher created for {robot_name} on topic {topic}')

        # Objective queue
        self.objectives = []
        self.cost_responses = {}

        # Publisher for broadcasting objectives
        self.offer_objective_pub = self.create_publisher(NavTaskCoordsMci, '/offer_objective', 10)

        # Subscriber for cost responses from robots
        self.cost_sub = self.create_subscription(
            CostMci,
            '/cost_response',
            self.handle_cost_response,
            10
        )

        self.task_sub = self.create_subscription(
            NavTaskMci,
            '/sendTaskMci',
            self.handle_task,
            10
        )
        self.retry_timer = None
    
    def handle_task(self, msg):
        pickup = msg.pickup
        dropoff = msg.dropoff
        self.get_logger().info(f'Received task: pickup {pickup}, dropoff {dropoff}')
        factory_start = self.pos_factories_lookup[pickup]
        factory_end = self.pos_factories_lookup[dropoff]
        self.get_logger().info(f'Factory start: {factory_start}, factory end: {factory_end}')
        self.objectives.append({'pickup_x': factory_start['x'], 'pickup_y': factory_start['y'], 'pickup_orientation': factory_start['orientation'], 'dropoff_x': factory_end['x'], 'dropoff_y': factory_end['y'], 'dropoff_orientation': factory_end['orientation']})
        self.get_logger().info(f'Objectives: {self.objectives}')
        self.publish_next_objective()
        

    def publish_next_objective(self):
        if self.retry_timer:
            self.retry_timer.cancel() 
        if self.objectives:
            current_objective = self.objectives[0]

            # Publish the current objective to all robots
            objective_msg = NavTaskCoordsMci()
            objective_msg.pickup_x = current_objective['pickup_x']
            objective_msg.pickup_y = current_objective['pickup_y']
            objective_msg.pickup_orientation = current_objective['pickup_orientation']

            objective_msg.dropoff_x = current_objective['dropoff_x']
            objective_msg.dropoff_y = current_objective['dropoff_y']
            objective_msg.dropoff_orientation = current_objective['dropoff_orientation']
            
            # Clear previous cost responses and start collecting new ones
            self.cost_responses = {}

            self.offer_objective_pub.publish(objective_msg)
            self.get_logger().info('Published new objective to robots')


            # Set a timer to wait for cost responses and make a decision
            self.cost_timer = self.create_timer(1.0, self.evaluate_cost_responses)

    def handle_cost_response(self, msg):
        # Collect cost responses from robots
        robot_name = msg.robot_name
        self.cost_responses[robot_name] = msg.cost
        self.get_logger().info(f'Received cost from {robot_name}: {msg.cost}')

    def evaluate_cost_responses(self):
        self.cost_timer.cancel()
        if not self.cost_responses:
            self.get_logger().info("No cost responses received; re-publishing objective in 4 seconds")
            self.retry_timer = self.create_timer(4.0, self.publish_next_objective)
            return
        
        current_objective = self.objectives.pop(0)

        # Find the robot with the lowest cost
        chosen_robot = min(self.cost_responses, key=self.cost_responses.get)
        lowest_cost = self.cost_responses[chosen_robot]
        self.get_logger().info(f'Assigning objective to {chosen_robot} with cost {lowest_cost}')

        # Send the assignment to the chosen robot
        objective_msg = NavTaskCoordsMci()
        # Publish the current objective to all robots
        objective_msg = NavTaskCoordsMci()
        objective_msg.pickup_x = current_objective['pickup_x']
        objective_msg.pickup_y = current_objective['pickup_y']
        objective_msg.pickup_orientation = current_objective['pickup_orientation']

        objective_msg.dropoff_x = current_objective['dropoff_x']
        objective_msg.dropoff_y = current_objective['dropoff_y']
        objective_msg.dropoff_orientation = current_objective['dropoff_orientation']

        # Publish the objective specifically to the chosen robot
        self.robot_publishers[chosen_robot].publish(objective_msg)
        self.get_logger().info(f'Published objective to {chosen_robot}')

def main(args=None):
    rclpy.init(args=args)
    dispatcher = DispatcherNode()
    rclpy.spin(dispatcher)
    dispatcher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
