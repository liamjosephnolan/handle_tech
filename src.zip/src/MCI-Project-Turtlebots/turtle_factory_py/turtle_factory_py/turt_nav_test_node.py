import rclpy
from rclpy.node import Node

from std_msgs.msg import String

from interfaces_mci.msg import NavMci

class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('minimal_publisher')
        self.publisher_ = self.create_publisher(NavMci, 'sendNavGoalMci', 10)
        timer_period = 60  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 1

    def timer_callback(self):
        if self.i % 2 == 0:
            msg = NavMci()
            msg.x = 0.0
            msg.y = 0.0
            msg.orientation = 0
            msg.goal_type = 'dock'
            self.get_logger().info('Dock')
        else:
            msg = NavMci()
            msg.x = -2.0
            msg.y = 0.0
            msg.orientation = 180
            msg.goal_type = 'fact'
            self.get_logger().info('Fact!')
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing! x y and orient')
        self.i += 1


def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = MinimalPublisher()

    rclpy.spin(minimal_publisher)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()