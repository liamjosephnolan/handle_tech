import rclpy
from rclpy.node import Node
from enum import Enum
from sensor_msgs.msg import BatteryState  
from rclpy.qos import QoSProfile, ReliabilityPolicy
import yaml
import os
from ament_index_python.packages import get_package_share_directory
import random
from std_msgs.msg import String

from interfaces_mci.msg import NavMci, CostMci, NavTaskCoordsMci
from irobot_create_msgs.msg import DockStatus

class TurtleState(Enum):
    IDLE = 1
    CHARGING = 2
    OBJECTIVE = 3
    DOCKING = 4
    PROVISIONING = 5
    OBJECTIVE_PICKUP = 6
    OBJECTIVE_DROPOFF = 7
    STARTUP = 8

class TurtleStateMachine(Node):
    def __init__(self):
        super().__init__('turtle_state_machine')

        self.state = TurtleState.STARTUP

        self.get_logger().info(f'State initialized to {self.state.name}')
        self.timer = self.create_timer(1.0, self.state_machine_callback)

        self.namespace = self.get_namespace()
        self.robot_name = self.namespace.strip('/')

        config = os.path.join(get_package_share_directory('turtle_factory_py'),
        'robots.yml'
        )
        self.get_logger().info(f'Loading configuration from {config}')
        
        with open(config) as file:
            self.configuration = yaml.safe_load(file)

        self.get_logger().info(f'Configuration loaded: {self.configuration}')

        self.pos_docks_lookup = {robot["name"]: robot for robot in self.configuration["pos_docks"]}

        # Create a QoS profile with Best Effort reliability
        qos_profile = QoSProfile(depth=10)
        qos_profile.reliability = ReliabilityPolicy.BEST_EFFORT  # Set to Best Effort

        # Subscriber to the battery state topic
        self.battery_status_sub = self.create_subscription(
            BatteryState,         
            self.namespace + '/battery_state',
            self.battery_status_callback,  
            qos_profile
        )

        self.battery_level = 0
        self.thres_lower = 15
        self.thres_upper = 15 # TODO add to config file

        self.dock_status_sub = self.create_subscription(
            DockStatus,
            'dock_status',
            self.dock_status_callback,
            qos_profile
        )

        self.is_docked = None

        self.publisher_ = self.create_publisher(NavMci, 'sendNavGoalMci', 10)

        self.cost_pub = self.create_publisher(CostMci, '/cost_response', 10)

        self.offer_objective_sub = self.create_subscription(
            NavTaskCoordsMci,
            '/offer_objective',
            self.handle_offer,
            10
        )

        self.assign_objective_sub = self.create_subscription(
            NavTaskCoordsMci,
            self.namespace + '/assign_objective',
            self.handle_task,
            10
        )

        self.new_offer = False
        self.offer = None

        self.new_task = False
        self.task = None

        self.stop_provisioning = False

        self.nav_completed = False
        self.nav_completed_sub = self.create_subscription(
            String,
            'nav_goal_reached',
            self.nav_completed_callback,
            10
        )

        
    def nav_completed_callback(self, msg):
        self.get_logger().info('Navigation completed')
        self.nav_completed = True

    def calculate_cost(self, x, y):
        #TODO better cost func, euclidian distance
        return random.randint(0, 100)

    
    def handle_offer(self, msg):
        self.get_logger().info('Received offer')
        self.new_offer = True
        self.offer = msg

    def handle_task(self, msg):
        self.new_task = True
        self.task = msg
        self.get_logger().info('Received task')

    def stop_provisioning_callback(self):
        self.get_logger().info('Stopping timer')
        self.provisioning_timer.cancel()
        if self.state == TurtleState.PROVISIONING:
            self.get_logger().info('Provisioning stopped')
            self.stop_provisioning = True

    def dock_status_callback(self, msg):
        # Update dock status and log message
        self.is_docked = msg.is_docked

    def battery_status_callback(self, msg):
        # Update battery percentage
        self.battery_level = msg.percentage * 100  # Convert from 0-1 to 0-100 scale

    def state_machine_callback(self):
        # Stop the timer to prevent new calls until the current state handler finishes
        self.timer.cancel()

        self.get_logger().info('State Machine Callback')

        # Call the appropriate handler for the current state
        if self.state == TurtleState.IDLE:
            self.handle_idle()
        elif self.state == TurtleState.CHARGING:
            self.handle_charging()
        elif self.state == TurtleState.OBJECTIVE:
            self.handle_objective()
        elif self.state == TurtleState.DOCKING:
            self.handle_docking()
        elif self.state == TurtleState.PROVISIONING:
            self.handle_provisioning()
        elif self.state == TurtleState.OBJECTIVE_PICKUP:
            self.handle_objective_pickup()
        elif self.state == TurtleState.OBJECTIVE_DROPOFF:
            self.handle_objective_dropoff()
        elif self.state == TurtleState.STARTUP:
            self.handle_startup()

        # Restart the timer after handling the state
        self.timer.reset()

    def handle_startup(self):
        self.get_logger().info('Handling STARTUP state')
        newState = TurtleState.STARTUP

        # Startup finished condtions
        if self.battery_level > 0 and self.is_docked is not None:
            if self.is_docked:
                newState = TurtleState.CHARGING
            else:
                newState = TurtleState.IDLE

        self.state = newState


    def handle_idle(self):
        self.get_logger().info('Handling IDLE state')

        newState = TurtleState.IDLE
        
        if self.new_offer:
            self.new_offer = False
            self.get_logger().info('Calculating cost')
            cost = float(self.calculate_cost(self.offer.pickup_x, self.offer.pickup_y))
            cost_msg = CostMci()
            cost_msg.cost = cost
            cost_msg.robot_name = self.robot_name
            self.cost_pub.publish(cost_msg)
            self.get_logger().info('Publishing cost')
            newState = TurtleState.PROVISIONING
    
            self.provisioning_timer = self.create_timer(2.0, self.stop_provisioning_callback)

        # Check for low battery
        elif self.battery_level < self.thres_lower:
            newState = TurtleState.DOCKING
        
        self.state = newState
    
    def handle_provisioning(self):
        self.get_logger().info('Handling PROVISIONING state')
        newState = TurtleState.PROVISIONING
        if self.stop_provisioning:
            newState = TurtleState.IDLE
        if self.new_task:
            newState = TurtleState.OBJECTIVE
        self.state = newState

    def handle_charging(self):
        self.get_logger().info('Handling CHARGING state')
        # Check battery level
        newState = TurtleState.CHARGING

        self.get_logger().info(f'Battery level: {self.battery_level:.2f}%')

        if self.battery_level > self.thres_upper:
            newState= TurtleState.IDLE

        self.state = newState
    
    def handle_objective_pickup(self):
        newState = TurtleState.OBJECTIVE_PICKUP

        if self.nav_completed:
            self.nav_completed = False
            newState = TurtleState.OBJECTIVE_DROPOFF

            self.get_logger().info('Navigating to task dropoff')
            goal = NavMci()
            goal.x = self.task.dropoff_x
            goal.y = self.task.dropoff_y
            goal.orientation = self.task.dropoff_orientation
            goal.goal_type = 'fact'
            self.publisher_.publish(goal)
            self.get_logger().info('Publishing goal')

        self.state = newState

    def handle_objective_dropoff(self):
        newState = TurtleState.OBJECTIVE_DROPOFF

        if self.nav_completed:
            self.nav_completed = False
            # Return to dock? TODO Decide what to do
            newState = TurtleState.DOCKING

        self.state = newState
        

    def handle_objective(self):
        self.get_logger().info('Handling OBJECTIVE state')
        newState = TurtleState.OBJECTIVE

        if self.new_task:
            self.new_task = False

            self.get_logger().info('Navigating to task pickup')
            newState = TurtleState.OBJECTIVE_PICKUP
            goal = NavMci()
            goal.x = self.task.pickup_x
            goal.y = self.task.pickup_y
            goal.orientation = self.task.pickup_orientation
            goal.goal_type = 'fact'
            self.publisher_.publish(goal)
            self.get_logger().info('Publishing goal')
        
        self.state = newState

    def handle_docking(self):
        self.get_logger().info('Handling DOCKING state')

        newState = TurtleState.DOCKING


        msg = NavMci()
        dock = self.pos_docks_lookup[self.robot_name]
        self.get_logger().info(f'Docking at {dock}')
        msg.x = dock['x']
        msg.y = dock['y']
        msg.orientation = dock['orientation']
        msg.goal_type = 'dock'
        self.get_logger().info('Dock')
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing! x y and orient')

        newState = TurtleState.CHARGING

        self.state = newState

def main(args=None):
    rclpy.init(args=args)
    node = TurtleStateMachine()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()