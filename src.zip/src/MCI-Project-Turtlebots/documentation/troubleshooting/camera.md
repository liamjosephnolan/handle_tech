# Camera

>[!IMPORTANT]
> oakd nodes (camera nodes) shut down while the robots are docked.

[https://robotics.stackexchange.com/questions/111379/turtlebot4-oak-d-camera-stops-publishing-messages-after-few-seconds-on-bootup](https://robotics.stackexchange.com/questions/111379/turtlebot4-oak-d-camera-stops-publishing-messages-after-few-seconds-on-bootup)
Image can be viewed with 

```bash
ros2 run rqt_image_view rqt_image_view
```

