If you want the turtlebot to stop undocking you can manually trigger an estop state. This is a bit of a work around and I will look into the docking service next but for now toggling and untoggling estop states is very easy. You can just use the following commands in terminal


### Turn E_stop on
```bash
ros2 service call /robot6/e_stop irobot_create_msgs/srv/EStop "{e_stop_on: true}"
```

### Turn E_stop off

```bash
ros2 service call /robot6/e_stop irobot_create_msgs/srv/EStop "{e_stop_on: false}"
```