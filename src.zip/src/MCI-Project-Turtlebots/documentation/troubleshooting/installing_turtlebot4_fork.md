
# Installing the Turtlebot4 Navigation fork 

> [!IMPORTANT]
> Not needed anymore, see [namespace](namespace.md)
>

In the TurtleBot4Navigator we have to change the constructor arguments to pass through the namespace parameter to the BasicNavigator class.

``` py 
class TurtleBot4Navigator(BasicNavigator):
    is_docked = None
    creating_path = False

    def __init__(self, namespace=''):
        super().__init__(namespace=namespace)

```

This is a local change tho, so more investigation is needed.

> [!IMPORTANT]
> This info is valid, but superseeded.
> See [namespace](namespace.md) for a better solution.


```bash
cd ~/ros2_ws

sudo apt remove ros-humble-turtlebot4-navigation

rm -rf build/ install/ log/

rosdep install --from-paths src/MCI-Project-Turtlebots/turtlebot4/ --ignore-src -r -y

colcon build --symlink-install

source install/setup.bash
```