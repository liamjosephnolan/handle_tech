# Namespace

We just found out that the `namespace:/robot4` syntax is deprecated and does not work.

The new syntax is:

```bash
--ros-args -r __ns:=/robot4
```
-r stands for remap.

Example:
```bash
ros2 run turtle_factory_py turt_nav_node --ros-args -r __ns:=/robot4
```

This has been confirmed to work with the previously troublesome TurtleBot4Navigator class, aswell as our custom classes.
We keep this approach for now, as this holds the benefit of not needing to worry about namespaces in our nodes/code.



