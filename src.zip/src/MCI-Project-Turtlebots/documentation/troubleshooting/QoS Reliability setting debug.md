
I ran into some issues with mismatched QoS reliability type. You can manually specify QoS reliability type like this:

```python
from rclpy.qos import QoSProfile, ReliabilityPolicy

# Create a QoS profile with Best Effort reliability
qos_profile = QoSProfile(depth=10)
qos_profile.reliability = ReliabilityPolicy.BEST_EFFORT  # Set to Best Effort
```

Your warning might look something like this:

```bash
ros2 run turtle_factory_py master_node [WARN] [1730888294.523914265] [battery_dock_monitor]: New publisher discovered on topic '/robot6/battery_state', offering incompatible QoS. No messages will be received from it. Last incompatible policy: RELIABILITY
```

You can check effort type with the --verbose modifier

```bash
ros2 topic info /robot6/dock_status --verbose
```

