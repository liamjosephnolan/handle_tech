# Turtlebot Project

Welcome to guide for using the turtlebots 4.

This documentation is divided in several parts:

- Getting started/Walkthrough of the basic built in functions (e.g. nav2, slam, rviz)
- Using code (nodes) to interact with the robots
- An example project 
- Various ressources for troubleshooting
- Mechanical section including cAD files, modified parts to inital setup and supplier / manufacturing hints
