# Some mechanical meassurements



The Elevators that are currently assembled have a vertical delta of **15cm**.

The factory sits 295.30mmm above the floor (I.E We will need a crate that is roughly 295mm tall

The current design has a vertical delta of 73.5mm 




# Design Updates
Updated factory angle from 5deg to 7.5deg resulting in a steeper angle. This creates a vertical drop of 68.687mm


# Item Orders

- 10mm Arcylic sheeting
- Shaft Collars
- White Roller Bearings (Not actaully needed)
- Black Roller Bearings
- Shorter Linear Bearings (Or change the design to use old ones)
- Clevis
- Clevis Pin
- Clevis Pin E Clip 
- Clevis Pin Bearings
- Black Roller Bolts
- White Roller Bolts
- White Roller Nuts
- Black Roller Nuts
- Hat threaded rod + nuts
- Hat Angle Bracket
- Hat Angle Bracket Bolt
- Hat Angle Bracket Nut

Details can be found in the order list. 
  
