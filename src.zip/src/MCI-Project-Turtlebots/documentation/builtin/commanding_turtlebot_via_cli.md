# How to command the turtlebot to do useful stuff via the command line interface (cli)

## docking the robot
ros2 action send_goal /robot7/dock irobot_create_msgs/action/Dock "{ }"

## undocking the robot
ros2 action send_goal /robot7/undock irobot_create_msgs/action/Undock "{ }"

## teleoperation (driving backwards is not possible)
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args -r __ns:=/robot7


# make the turtlebot play a two notes (400 Hz followed by 800 Hz)
ros2 action send_goal /robot7/audio_note_sequence irobot_create_msgs/action/AudioNoteSequence "{iterations: 1, note_sequence: {notes: [{frequency: 400, max_runtime: {sec: 1, nanosec: 0}}, {frequency: 800, max_runtime: {sec: 1, nanosec: 0}}], append: false}}"

