# Creating a map

## Launch Nav2 stack
```bash
ros2 launch turtlebot4_navigation nav2.launch.py namespace:=/robot4
```

## Launch slam
```bash
ros2 launch turtlebot4_navigation slam.launch.py namespace:=/robot4
```

## Launch RViz 
```bash
ros2 launch turtlebot4_viz view_robot.launch.py namespace:=/robot4
```

Drive around using RViz nav goals.

Once you are happy with the map call:

```bash
ros2 run nav2_map_server map_saver_cli -f "map_name" --ros-args -p map_subscribe_transient_local:=true -r __ns:=/robot4
```