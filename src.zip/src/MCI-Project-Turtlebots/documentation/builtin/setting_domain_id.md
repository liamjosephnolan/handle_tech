# Setting Domain ID

## Edit the setup.bash file in the /etc/turtlebot4 directory.

```bash
sudo nano /etc/turtlebot4/setup.bash
```

In there set the ROS_DOMAIN_ID parameter.

>[!IMPORTANT]
> You have to add 
> ```
> source /etc/turtlebot4/setup.bash
> ```
> to your ~.bashrc. 
> Reload your terminal!



## Using export
```bash
sudo export ROS_DOMAIN_ID=40
```

This is only valid for the current terminal session.
It is useful if you are running nodes for multiple robots in different terminals.



## Test 
Use this command to confirm that your terminal uses the right Domain ID.
```bash
env | grep ROS
```