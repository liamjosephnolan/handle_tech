# Network related notes

> [!IMPORTANT]
> The IPs of the TurtleBots changed from `192.168.50.0/24` to `192.168.88.0/24`, but the last digits remain the same.

## Router Information

### Asus Router Zentrum PRA
- **Login Site:** [http://router.asus.com](http://router.asus.com)
- **Username:** `admin`
- **Password:** `k0k0l0l0`
- **SSID 5GHz:** `ZentrumPRA`
- **SSID 2.4GHz:** `ZentrumPRA_2.4`
- **Wi-Fi Password:** `wlpassword013`

### MCI Teaching 03
- **Login Site:** [http://192.168.88.1/](http://192.168.88.1/)
- **Username:** `mci_teaching03`
- **Password:** `A3PLE/RH)Q5`
- **SSID 5GHz:** `mci_teaching03`
  - **Wi-Fi Password:** `D8ETL2D9SW`
- **SSID 2.4GHz:** `mci_teaching03_2_4`
  - **Wi-Fi Password:** `D8ETL2D9SW`

### MCI Teaching 04
- **Login Site:** [http://192.168.88.1/](http://192.168.88.1/)
- **Username:** `mci_teaching04`
- **Password:** `G&VB!YF%96T`
- **SSID 5GHz:** `mci_teaching04`
  - **Wi-Fi Password:** `LX36YQKU6Z`

> The Asus router was initially set up for the TurtleBot robots with the drawback to not have internet connection. Tests were conducted on the other two MCI networks, but bandwidth issues prevented proper connection. As a result, the decision was made to stay with the inital setup on the Asus router. Ideally, the TurtleBots should connect to a network that provides both robot connectivity and internet access for educational purposes.

---

## TurtleBot Discovery Methods

### **Simple Discovery**
- Uses a direct peer-to-peer method where each TurtleBot needs the IP address of the host computer.
- Suitable for small, static networks with minimal configuration.
- Requires manual IP address setup.

### **Discovery Server**
- Uses a central server to manage connections between multiple robots and computers.
- More scalable and dynamic, allowing automatic discovery without manual IP setup.
- Ideal for larger networks or environments where robots frequently connect and disconnect.

### **Recommended Approach**
For educational purposes and ease of use, **Discovery Server** is the preferred method, as it simplifies network configuration and allows for greater flexibility in robot interactions. However, due to unstable network connections, it could not be used in the current setup. Improving network stability should be considered as a next step to enable the use of the Discovery Server for better scalability and management.

### **Further information**
https://docs.ros.org/en/humble/Tutorials/Advanced/Discovery-Server/Discovery-Server.html

