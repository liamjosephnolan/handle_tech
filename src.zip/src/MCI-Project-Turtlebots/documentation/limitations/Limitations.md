# Limitations

Throughout the development of the project, several limitations were encountered. 

These are listed here together with the current mitigations for those.

## 1. **Hardware Limitations**

### Charge Rate

The charge rate was mesured to be 0.5A.

The discharge rate was mesured to be 1A, while idleing.

This imposes a limitation on the amount of time the robot can be used before needing to be recharged.

Keep in mind that the discharge rate is only mesured while ideling, for driving around the rate is expected to be significantly higher.


These rate imply a limitation on robots driving around at the same time.

To have a balance of charge in the whole system, two turtlebots need to charge at all times to balance the discharge of one ideling robot.

For driving, this will most likely be at least 3 robots that need to charge.


This imposes great challanges for the continous operation.

> [!IMPORTANT]
> 3 robots need to charge to balance the discharge rate of one. 
> This can not be mitigated by a larger battery, as these are charge **rates**.

This limitation also majorly influenced our design dession to not use the camera for docking, but use docs for the factories.
The idea behind this was to disconnect the camera, as it is one of the biggest energy consumers.

### Battery

In addition to the charge rate problem, the battery life is fairly limited, which mainly imposes limitations in the development process.



## 2. Software

The ROS2 framework itself is well documented. 

The turtlebot packages and specific functions are only documented in a limited matter.
Some expample codes are outdated and rarly anyone uses the turtlebots 4, which leads to a shortage of high quality only ressources, besides the manufacturers documentation.



## 3. MCI related
The documentation and files of the old projects are not all accesable and/or are unstructured to the point were it is hard to understand what happend when.

Code snippets in the most recent documentation were in part not executable (Most likely because of newer versions and changes in those).


## 4. Network
It is not possible in the current setup to access the internet for the turtlebot network.
A lot of time was invested in finding a possible solution with other routers supplied by the IT.
There the internet worked, but the network itself had relibability issues with the turtlebots.

This again imposes a challange mainly on the development process.
Updating the code on the turtlebots and updating their software involves significantly more manual labor, as it first has to be transfered from an external device, were it was downloaded prior.


