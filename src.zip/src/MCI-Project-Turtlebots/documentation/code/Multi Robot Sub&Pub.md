
Ran into a problem where I had to create sub/pub service for multiple robots. Rather than hard coding a service for each of the robots I found a nice way to iterate through a list and create these services for each robot. 

Here is a quick example:

```python
robot_list = ['robot4','robot6']

for robot in robot_list:
	self.dock_status_sub = self.create_subscription(
		DockStatus,
		'/'+robot+'/dock_status',
		self.dock_status_callback,
		qos_profile
	)

	self.needs_charging_pub = self.create_publisher(
		Bool,
		'/'+robot+'/needs_charging',
		10
	)
```
