
# Navigate using Python code

## Use a presaved map
In order for the navigation through code we need to use a presaved map.
See [create map](../../builtin/creating_map.md).




## Commands walkthrough

### Launch Nav2 stack
```bash
ros2 launch turtlebot4_navigation nav2.launch.py namespace:=/robot4
```

### Launch localization, needs presaved map
```bash
ros2 launch turtlebot4_navigation localization.launch.py map:=map_name.yaml namespace:=/robot4
```
After launching this we have to set an inital pose in rviz through the 2D Pose Estimate button.

### Launch RViz (optional)
```bash
ros2 launch turtlebot4_viz view_robot.launch.py namespace:=/robot4
```

### Launch custom node
```bash
ros2 launch turtlebot4_viz view_robot.launch.py namespace:=/robot4
```


## Troubleshooting

If you get
```bash
amcl/get_state service not available, waiting...
```
you probably launched slam, instead do the following.

> [!IMPORTANT]
> Launch localization and not slam as the amcl/get_state is not available for slam.

Example: Replace with your map name.
```bash
ros2 launch turtlebot4_navigation localization.launch.py map:=map_name.yaml namespace:=/robot4
```