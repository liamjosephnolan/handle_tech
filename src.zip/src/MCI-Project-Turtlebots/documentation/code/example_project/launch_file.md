# Launch file

The launch file launches all necessary nodes.

```bash
ros2 launch turtle_factory_py mci_launch.launch.py namespace:=/robot4 map:=map_name.yaml
```

## Arguments
### namespace
Namespace e.g. /robot4
### map
Path to the map that should be used.