## Elevator Node

Please note that because of the GPIO library the elevator node must be run on the turtlebot. Files can be copied to the turtlebot remotely 


To copy files onto turtlebot

```
scp -r ~/ros2_ws/src/MCI-Project-Turtlebots/turtle_factory_py/ ubuntu@192.168.50.203:/home/ubuntu/ros2_ws/src
```


General Procedure is as follows

1. Ssh into turtlebot
2. Change into ros2 ws
3. Colcon build
4. Source install/setup.bash
5. ros2 run turtle_factory_py elevator_node

NOTE: Sometimes when building it has thrown a clockskew error. This was fixed by using package-select option when building colcon. 

Currently if the node is ran while the limit switch is triggered it will not work

NOTE: -1 is correct direction (+pos moves up and -pos moves down)


To send position goals to the robot the following can be used

```
ros2 action send_goal /drive_elevator interfaces_mci/action/Elevator "{position: 10}"
```
