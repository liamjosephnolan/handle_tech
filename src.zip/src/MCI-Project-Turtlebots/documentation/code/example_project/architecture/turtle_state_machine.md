# Turtle State Machine Node

## State diagram
``` mermaid
stateDiagram-v2
  [*] --> STARTUP
  STARTUP --> IDLE : if not docked
  STARTUP --> CHARGING : if docked
  IDLE --> DOCKING : battery < lower_threshold
  DOCKING --> CHARGING 
  IDLE --> PROVISIONING : offer received
  PROVISIONING --> IDLE : no objective received
  PROVISIONING --> OBJECTIVE : objective received
  OBJECTIVE --> OBJECTIVE_PICKUP : sent movement command to pickup
  OBJECTIVE_PICKUP --> OBJECTIVE_DROPOFF  : sent movement command to dropoff
  OBJECTIVE_DROPOFF --> DOCKING : reached dock
  CHARGING --> IDLE : battery > upper_threshold
```