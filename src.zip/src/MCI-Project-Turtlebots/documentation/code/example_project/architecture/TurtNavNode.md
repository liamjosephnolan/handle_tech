# TurtNavNode Class

## Input
### Coords
### Orientation
### GoalType
    park
    dock 
    fact

The start of the movement will be done implicitly.
If the robot is docked, we undock.
If the robot is parked, we just go straight to the goal pos. 
Same for factory.

