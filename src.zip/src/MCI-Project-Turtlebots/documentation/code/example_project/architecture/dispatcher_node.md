# Dispatcher Node

This node handles the allocation of the tasks to the robots. 

## Dispatcher logic flow
``` mermaid
sequenceDiagram
  autonumber
  loop Sub
      Master->>Master: Listen for new objectives
  end
  Master->>Turtle1: Request offer
  Master->>Turtle2: Request offer
  Master->>Turtle3: Request offer
  Turtle1->>Master: Offer! Cost: xy.
  Turtle2->>Master: Offer! Cost: xyz.
  Turtle3->>Master: Offer! Cost: xz.
  loop Wait for a specific time
      Master->>Master: Listen for offers
  end
  Master->>Turtle1: Do objective
```