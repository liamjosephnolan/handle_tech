# Node Architecture

## rqt graph
![rqt graph](../../../img/rosgraph.png)
