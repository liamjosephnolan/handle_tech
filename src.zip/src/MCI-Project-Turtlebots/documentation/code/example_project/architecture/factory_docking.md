# Factory docking
this document explains our choices made for docking to a factory.
-

Approaching a factory and docking to it is done in two steps:
 
 - Navigate the turtlebot close to the pickup- or dropoff point of a factory.
 - use the 'docking' function of the create3 and the IR marker of the dock to finely dock to the factory.

 for this to work, the factory utilizes the docks as docking points.