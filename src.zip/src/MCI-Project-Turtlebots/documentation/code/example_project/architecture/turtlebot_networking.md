# Networking 


## Networking
https://turtlebot.github.io/turtlebot4-user-manual/setup/networking.html


### Network Configurations

Simple Discovery vs Discovery Server

Something to do with DDS


### Multiple robots on the same network

Domain ID vs Namespacing


