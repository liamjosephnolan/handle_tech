 Cheatsheet
This document will contain useful and frequently used ROS2, Linux, and Turtlebot commands

## Links
Button colors: https://iroboteducation.github.io/create3_docs/hw/face/

Reset with ethernet: https://turtlebot.github.io/turtlebot4-user-manual/setup/basic.html#updating-the-turtlebot-4

Explanation of Discovery Sever: https://fast-dds.docs.eprosima.com/en/latest/fastdds/ros2/discovery_server/ros2_discovery_server.html#ros-2-introspection


## Git hub working setup 

### Update to Github after local file change
Add files to local repo 
    
    git add .

Commit files
    
    git commit -m "comment" 

Push files
    
    git push
### Avoid merge conflicts
check the status to see if you have to pull first -> then do the change 
    
    git status

### Pull files 
    git pull 


## Connecting to Turtlebot

First make sure that your ROS2 Domain ID is setup properly in your setup.bash

```bash
sudo nano /etc/turtlebot4/setup.bash
```

Now paste or update the following. Make sure your robot domain ID is correct
```
source /opt/ros/humble/setup.bash
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export CYCLONEDDS_URI=/etc/turtlebot4/cyclonedds_pc.xml
export ROS_DOMAIN_ID=<robot_domain_id>
```

### SSH into Turtlebot
```bash
ssh ubuntu@<turtlebot_IP_address>
```


