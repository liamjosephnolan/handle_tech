# Open Tasks

## Mechanical
- Vertical displacement assesment
- Modifying the tilt of the factory
- Mofifying the elevator design

## ROS 2
- Setup networking
- Test connection

- Figure out coordinate stuff

- RVIS
    - What is it doing?
    - Coord System
    - How do the robots sync the coord system??
    - Currently working through RVIZ Mapping issues
        - Potentially issues with specific turtlebots

- Docking issues
    - Why do the robots undock on power up
        - I think this is creating issues with RVIZ
