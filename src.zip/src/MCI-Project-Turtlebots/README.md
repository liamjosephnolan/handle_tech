# MCI-Project-Turtlebots-Documentation
The place for all the documentation of 'project 2'.

## Documentation
The documentation can be found under documentation.
It can also be viewed in a webbrowser using MKDocs.

### Using MKDocs

To install mkdocs you need python.
Either create a virtual environment (recommended) or use your global installation.
```bash
pip install mkdocs
pip install mkdocs-material
pip install mkdocs-callouts
pip install markdown-callouts
```

You can also use the requirements.txt to install all the dependencies, see the next section for more infos

To start mkdocs run the following command in the repos directory (the dir holding the mkdocs.yml).

```bash
mkdocs serve
```

## Installation of example project (and mkdocs)

All the requirements for the example project are listed in requirements.txt.
To install those, use the pip -r flag.
Again it is recommended to use a venv.

```bash
pip install -r requirements.txt
```