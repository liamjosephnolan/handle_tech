from launch_ros.actions import Node, PushRosNamespace
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription, Event
from launch.actions import DeclareLaunchArgument, GroupAction, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource

import os
def generate_launch_description():
    namespace_launch_arg = DeclareLaunchArgument(
        'namespace',
        default_value='',
        description='Robots namespace'
    )
    map_name = DeclareLaunchArgument(
        'map',
        default_value='~/aula_V1.yaml',
        description='map to be used in localization'
    )

    namespace = LaunchConfiguration('namespace')

    localization = IncludeLaunchDescription(
      PythonLaunchDescriptionSource([os.path.join(
         get_package_share_directory('turtlebot4_navigation'), 'launch'),
         '/localization.launch.py']),
         launch_arguments={'map': LaunchConfiguration('map')}.items(),
    )

    nav2 = IncludeLaunchDescription(
      PythonLaunchDescriptionSource([os.path.join(
         get_package_share_directory('turtlebot4_navigation'), 'launch'),
         '/nav2.launch.py']),
    )

    rivz = IncludeLaunchDescription(
      PythonLaunchDescriptionSource([os.path.join(
         get_package_share_directory('turtlebot4_viz'), 'launch'),
         '/view_robot.launch.py']),
    )
    
    single_client = GroupAction([
    PushRosNamespace(namespace),
    Node(
        package='turtle_factory_py',
        executable='turt_nav_node',
        output='log',
        parameters=[{'namespace' : LaunchConfiguration('namespace')}]
    )
    ])
    ld = LaunchDescription([
            namespace_launch_arg,
            map_name,
    ])
    ld.add_action(single_client)
    ld.add_action(localization)
    ld.add_action(nav2)
    ld.add_action(rivz)
    
    return ld