// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces_mci:msg/CostMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__COST_MCI__BUILDER_HPP_
#define INTERFACES_MCI__MSG__DETAIL__COST_MCI__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces_mci/msg/detail/cost_mci__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces_mci
{

namespace msg
{

namespace builder
{

class Init_CostMci_robot_name
{
public:
  explicit Init_CostMci_robot_name(::interfaces_mci::msg::CostMci & msg)
  : msg_(msg)
  {}
  ::interfaces_mci::msg::CostMci robot_name(::interfaces_mci::msg::CostMci::_robot_name_type arg)
  {
    msg_.robot_name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces_mci::msg::CostMci msg_;
};

class Init_CostMci_cost
{
public:
  Init_CostMci_cost()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CostMci_robot_name cost(::interfaces_mci::msg::CostMci::_cost_type arg)
  {
    msg_.cost = std::move(arg);
    return Init_CostMci_robot_name(msg_);
  }

private:
  ::interfaces_mci::msg::CostMci msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces_mci::msg::CostMci>()
{
  return interfaces_mci::msg::builder::Init_CostMci_cost();
}

}  // namespace interfaces_mci

#endif  // INTERFACES_MCI__MSG__DETAIL__COST_MCI__BUILDER_HPP_
