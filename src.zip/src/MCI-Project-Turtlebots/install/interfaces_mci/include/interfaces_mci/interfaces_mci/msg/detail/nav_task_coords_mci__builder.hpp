// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces_mci:msg/NavTaskCoordsMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__BUILDER_HPP_
#define INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces_mci/msg/detail/nav_task_coords_mci__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces_mci
{

namespace msg
{

namespace builder
{

class Init_NavTaskCoordsMci_dropoff_orientation
{
public:
  explicit Init_NavTaskCoordsMci_dropoff_orientation(::interfaces_mci::msg::NavTaskCoordsMci & msg)
  : msg_(msg)
  {}
  ::interfaces_mci::msg::NavTaskCoordsMci dropoff_orientation(::interfaces_mci::msg::NavTaskCoordsMci::_dropoff_orientation_type arg)
  {
    msg_.dropoff_orientation = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces_mci::msg::NavTaskCoordsMci msg_;
};

class Init_NavTaskCoordsMci_dropoff_y
{
public:
  explicit Init_NavTaskCoordsMci_dropoff_y(::interfaces_mci::msg::NavTaskCoordsMci & msg)
  : msg_(msg)
  {}
  Init_NavTaskCoordsMci_dropoff_orientation dropoff_y(::interfaces_mci::msg::NavTaskCoordsMci::_dropoff_y_type arg)
  {
    msg_.dropoff_y = std::move(arg);
    return Init_NavTaskCoordsMci_dropoff_orientation(msg_);
  }

private:
  ::interfaces_mci::msg::NavTaskCoordsMci msg_;
};

class Init_NavTaskCoordsMci_dropoff_x
{
public:
  explicit Init_NavTaskCoordsMci_dropoff_x(::interfaces_mci::msg::NavTaskCoordsMci & msg)
  : msg_(msg)
  {}
  Init_NavTaskCoordsMci_dropoff_y dropoff_x(::interfaces_mci::msg::NavTaskCoordsMci::_dropoff_x_type arg)
  {
    msg_.dropoff_x = std::move(arg);
    return Init_NavTaskCoordsMci_dropoff_y(msg_);
  }

private:
  ::interfaces_mci::msg::NavTaskCoordsMci msg_;
};

class Init_NavTaskCoordsMci_pickup_orientation
{
public:
  explicit Init_NavTaskCoordsMci_pickup_orientation(::interfaces_mci::msg::NavTaskCoordsMci & msg)
  : msg_(msg)
  {}
  Init_NavTaskCoordsMci_dropoff_x pickup_orientation(::interfaces_mci::msg::NavTaskCoordsMci::_pickup_orientation_type arg)
  {
    msg_.pickup_orientation = std::move(arg);
    return Init_NavTaskCoordsMci_dropoff_x(msg_);
  }

private:
  ::interfaces_mci::msg::NavTaskCoordsMci msg_;
};

class Init_NavTaskCoordsMci_pickup_y
{
public:
  explicit Init_NavTaskCoordsMci_pickup_y(::interfaces_mci::msg::NavTaskCoordsMci & msg)
  : msg_(msg)
  {}
  Init_NavTaskCoordsMci_pickup_orientation pickup_y(::interfaces_mci::msg::NavTaskCoordsMci::_pickup_y_type arg)
  {
    msg_.pickup_y = std::move(arg);
    return Init_NavTaskCoordsMci_pickup_orientation(msg_);
  }

private:
  ::interfaces_mci::msg::NavTaskCoordsMci msg_;
};

class Init_NavTaskCoordsMci_pickup_x
{
public:
  Init_NavTaskCoordsMci_pickup_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavTaskCoordsMci_pickup_y pickup_x(::interfaces_mci::msg::NavTaskCoordsMci::_pickup_x_type arg)
  {
    msg_.pickup_x = std::move(arg);
    return Init_NavTaskCoordsMci_pickup_y(msg_);
  }

private:
  ::interfaces_mci::msg::NavTaskCoordsMci msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces_mci::msg::NavTaskCoordsMci>()
{
  return interfaces_mci::msg::builder::Init_NavTaskCoordsMci_pickup_x();
}

}  // namespace interfaces_mci

#endif  // INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__BUILDER_HPP_
