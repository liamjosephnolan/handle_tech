// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces_mci:msg/NavTaskCoordsMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__STRUCT_H_
#define INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/NavTaskCoordsMci in the package interfaces_mci.
typedef struct interfaces_mci__msg__NavTaskCoordsMci
{
  double pickup_x;
  double pickup_y;
  int64_t pickup_orientation;
  double dropoff_x;
  double dropoff_y;
  int64_t dropoff_orientation;
} interfaces_mci__msg__NavTaskCoordsMci;

// Struct for a sequence of interfaces_mci__msg__NavTaskCoordsMci.
typedef struct interfaces_mci__msg__NavTaskCoordsMci__Sequence
{
  interfaces_mci__msg__NavTaskCoordsMci * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces_mci__msg__NavTaskCoordsMci__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__STRUCT_H_
