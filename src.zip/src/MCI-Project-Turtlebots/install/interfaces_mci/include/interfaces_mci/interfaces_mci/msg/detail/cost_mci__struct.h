// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces_mci:msg/CostMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__COST_MCI__STRUCT_H_
#define INTERFACES_MCI__MSG__DETAIL__COST_MCI__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'robot_name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/CostMci in the package interfaces_mci.
typedef struct interfaces_mci__msg__CostMci
{
  double cost;
  rosidl_runtime_c__String robot_name;
} interfaces_mci__msg__CostMci;

// Struct for a sequence of interfaces_mci__msg__CostMci.
typedef struct interfaces_mci__msg__CostMci__Sequence
{
  interfaces_mci__msg__CostMci * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces_mci__msg__CostMci__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES_MCI__MSG__DETAIL__COST_MCI__STRUCT_H_
