// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces_mci:msg/NavTaskCoordsMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__STRUCT_HPP_
#define INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__interfaces_mci__msg__NavTaskCoordsMci __attribute__((deprecated))
#else
# define DEPRECATED__interfaces_mci__msg__NavTaskCoordsMci __declspec(deprecated)
#endif

namespace interfaces_mci
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct NavTaskCoordsMci_
{
  using Type = NavTaskCoordsMci_<ContainerAllocator>;

  explicit NavTaskCoordsMci_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pickup_x = 0.0;
      this->pickup_y = 0.0;
      this->pickup_orientation = 0ll;
      this->dropoff_x = 0.0;
      this->dropoff_y = 0.0;
      this->dropoff_orientation = 0ll;
    }
  }

  explicit NavTaskCoordsMci_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pickup_x = 0.0;
      this->pickup_y = 0.0;
      this->pickup_orientation = 0ll;
      this->dropoff_x = 0.0;
      this->dropoff_y = 0.0;
      this->dropoff_orientation = 0ll;
    }
  }

  // field types and members
  using _pickup_x_type =
    double;
  _pickup_x_type pickup_x;
  using _pickup_y_type =
    double;
  _pickup_y_type pickup_y;
  using _pickup_orientation_type =
    int64_t;
  _pickup_orientation_type pickup_orientation;
  using _dropoff_x_type =
    double;
  _dropoff_x_type dropoff_x;
  using _dropoff_y_type =
    double;
  _dropoff_y_type dropoff_y;
  using _dropoff_orientation_type =
    int64_t;
  _dropoff_orientation_type dropoff_orientation;

  // setters for named parameter idiom
  Type & set__pickup_x(
    const double & _arg)
  {
    this->pickup_x = _arg;
    return *this;
  }
  Type & set__pickup_y(
    const double & _arg)
  {
    this->pickup_y = _arg;
    return *this;
  }
  Type & set__pickup_orientation(
    const int64_t & _arg)
  {
    this->pickup_orientation = _arg;
    return *this;
  }
  Type & set__dropoff_x(
    const double & _arg)
  {
    this->dropoff_x = _arg;
    return *this;
  }
  Type & set__dropoff_y(
    const double & _arg)
  {
    this->dropoff_y = _arg;
    return *this;
  }
  Type & set__dropoff_orientation(
    const int64_t & _arg)
  {
    this->dropoff_orientation = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces_mci__msg__NavTaskCoordsMci
    std::shared_ptr<interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces_mci__msg__NavTaskCoordsMci
    std::shared_ptr<interfaces_mci::msg::NavTaskCoordsMci_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NavTaskCoordsMci_ & other) const
  {
    if (this->pickup_x != other.pickup_x) {
      return false;
    }
    if (this->pickup_y != other.pickup_y) {
      return false;
    }
    if (this->pickup_orientation != other.pickup_orientation) {
      return false;
    }
    if (this->dropoff_x != other.dropoff_x) {
      return false;
    }
    if (this->dropoff_y != other.dropoff_y) {
      return false;
    }
    if (this->dropoff_orientation != other.dropoff_orientation) {
      return false;
    }
    return true;
  }
  bool operator!=(const NavTaskCoordsMci_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NavTaskCoordsMci_

// alias to use template instance with default allocator
using NavTaskCoordsMci =
  interfaces_mci::msg::NavTaskCoordsMci_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces_mci

#endif  // INTERFACES_MCI__MSG__DETAIL__NAV_TASK_COORDS_MCI__STRUCT_HPP_
