// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces_mci:msg/NavTaskMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__NAV_TASK_MCI__BUILDER_HPP_
#define INTERFACES_MCI__MSG__DETAIL__NAV_TASK_MCI__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces_mci/msg/detail/nav_task_mci__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces_mci
{

namespace msg
{

namespace builder
{

class Init_NavTaskMci_dropoff
{
public:
  explicit Init_NavTaskMci_dropoff(::interfaces_mci::msg::NavTaskMci & msg)
  : msg_(msg)
  {}
  ::interfaces_mci::msg::NavTaskMci dropoff(::interfaces_mci::msg::NavTaskMci::_dropoff_type arg)
  {
    msg_.dropoff = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces_mci::msg::NavTaskMci msg_;
};

class Init_NavTaskMci_pickup
{
public:
  Init_NavTaskMci_pickup()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavTaskMci_dropoff pickup(::interfaces_mci::msg::NavTaskMci::_pickup_type arg)
  {
    msg_.pickup = std::move(arg);
    return Init_NavTaskMci_dropoff(msg_);
  }

private:
  ::interfaces_mci::msg::NavTaskMci msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces_mci::msg::NavTaskMci>()
{
  return interfaces_mci::msg::builder::Init_NavTaskMci_pickup();
}

}  // namespace interfaces_mci

#endif  // INTERFACES_MCI__MSG__DETAIL__NAV_TASK_MCI__BUILDER_HPP_
