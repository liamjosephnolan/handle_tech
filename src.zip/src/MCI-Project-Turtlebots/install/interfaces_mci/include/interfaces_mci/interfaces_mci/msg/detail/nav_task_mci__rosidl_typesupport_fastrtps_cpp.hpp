// generated from rosidl_typesupport_fastrtps_cpp/resource/idl__rosidl_typesupport_fastrtps_cpp.hpp.em
// with input from interfaces_mci:msg/NavTaskMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__NAV_TASK_MCI__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
#define INTERFACES_MCI__MSG__DETAIL__NAV_TASK_MCI__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "interfaces_mci/msg/rosidl_typesupport_fastrtps_cpp__visibility_control.h"
#include "interfaces_mci/msg/detail/nav_task_mci__struct.hpp"

#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-parameter"
# ifdef __clang__
#  pragma clang diagnostic ignored "-Wdeprecated-register"
#  pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
# endif
#endif
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif

#include "fastcdr/Cdr.h"

namespace interfaces_mci
{

namespace msg
{

namespace typesupport_fastrtps_cpp
{

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_interfaces_mci
cdr_serialize(
  const interfaces_mci::msg::NavTaskMci & ros_message,
  eprosima::fastcdr::Cdr & cdr);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_interfaces_mci
cdr_deserialize(
  eprosima::fastcdr::Cdr & cdr,
  interfaces_mci::msg::NavTaskMci & ros_message);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_interfaces_mci
get_serialized_size(
  const interfaces_mci::msg::NavTaskMci & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_interfaces_mci
max_serialized_size_NavTaskMci(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

}  // namespace typesupport_fastrtps_cpp

}  // namespace msg

}  // namespace interfaces_mci

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_interfaces_mci
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_cpp, interfaces_mci, msg, NavTaskMci)();

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES_MCI__MSG__DETAIL__NAV_TASK_MCI__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
