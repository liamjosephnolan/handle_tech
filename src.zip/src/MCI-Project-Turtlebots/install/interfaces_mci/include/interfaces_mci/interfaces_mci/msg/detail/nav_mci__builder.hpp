// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces_mci:msg/NavMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__NAV_MCI__BUILDER_HPP_
#define INTERFACES_MCI__MSG__DETAIL__NAV_MCI__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces_mci/msg/detail/nav_mci__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces_mci
{

namespace msg
{

namespace builder
{

class Init_NavMci_goal_type
{
public:
  explicit Init_NavMci_goal_type(::interfaces_mci::msg::NavMci & msg)
  : msg_(msg)
  {}
  ::interfaces_mci::msg::NavMci goal_type(::interfaces_mci::msg::NavMci::_goal_type_type arg)
  {
    msg_.goal_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces_mci::msg::NavMci msg_;
};

class Init_NavMci_orientation
{
public:
  explicit Init_NavMci_orientation(::interfaces_mci::msg::NavMci & msg)
  : msg_(msg)
  {}
  Init_NavMci_goal_type orientation(::interfaces_mci::msg::NavMci::_orientation_type arg)
  {
    msg_.orientation = std::move(arg);
    return Init_NavMci_goal_type(msg_);
  }

private:
  ::interfaces_mci::msg::NavMci msg_;
};

class Init_NavMci_y
{
public:
  explicit Init_NavMci_y(::interfaces_mci::msg::NavMci & msg)
  : msg_(msg)
  {}
  Init_NavMci_orientation y(::interfaces_mci::msg::NavMci::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_NavMci_orientation(msg_);
  }

private:
  ::interfaces_mci::msg::NavMci msg_;
};

class Init_NavMci_x
{
public:
  Init_NavMci_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavMci_y x(::interfaces_mci::msg::NavMci::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_NavMci_y(msg_);
  }

private:
  ::interfaces_mci::msg::NavMci msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces_mci::msg::NavMci>()
{
  return interfaces_mci::msg::builder::Init_NavMci_x();
}

}  // namespace interfaces_mci

#endif  // INTERFACES_MCI__MSG__DETAIL__NAV_MCI__BUILDER_HPP_
