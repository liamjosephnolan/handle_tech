// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from interfaces_mci:msg/NavTaskCoordsMci.idl
// generated code does not contain a copyright notice
#include "interfaces_mci/msg/detail/nav_task_coords_mci__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
interfaces_mci__msg__NavTaskCoordsMci__init(interfaces_mci__msg__NavTaskCoordsMci * msg)
{
  if (!msg) {
    return false;
  }
  // pickup_x
  // pickup_y
  // pickup_orientation
  // dropoff_x
  // dropoff_y
  // dropoff_orientation
  return true;
}

void
interfaces_mci__msg__NavTaskCoordsMci__fini(interfaces_mci__msg__NavTaskCoordsMci * msg)
{
  if (!msg) {
    return;
  }
  // pickup_x
  // pickup_y
  // pickup_orientation
  // dropoff_x
  // dropoff_y
  // dropoff_orientation
}

bool
interfaces_mci__msg__NavTaskCoordsMci__are_equal(const interfaces_mci__msg__NavTaskCoordsMci * lhs, const interfaces_mci__msg__NavTaskCoordsMci * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // pickup_x
  if (lhs->pickup_x != rhs->pickup_x) {
    return false;
  }
  // pickup_y
  if (lhs->pickup_y != rhs->pickup_y) {
    return false;
  }
  // pickup_orientation
  if (lhs->pickup_orientation != rhs->pickup_orientation) {
    return false;
  }
  // dropoff_x
  if (lhs->dropoff_x != rhs->dropoff_x) {
    return false;
  }
  // dropoff_y
  if (lhs->dropoff_y != rhs->dropoff_y) {
    return false;
  }
  // dropoff_orientation
  if (lhs->dropoff_orientation != rhs->dropoff_orientation) {
    return false;
  }
  return true;
}

bool
interfaces_mci__msg__NavTaskCoordsMci__copy(
  const interfaces_mci__msg__NavTaskCoordsMci * input,
  interfaces_mci__msg__NavTaskCoordsMci * output)
{
  if (!input || !output) {
    return false;
  }
  // pickup_x
  output->pickup_x = input->pickup_x;
  // pickup_y
  output->pickup_y = input->pickup_y;
  // pickup_orientation
  output->pickup_orientation = input->pickup_orientation;
  // dropoff_x
  output->dropoff_x = input->dropoff_x;
  // dropoff_y
  output->dropoff_y = input->dropoff_y;
  // dropoff_orientation
  output->dropoff_orientation = input->dropoff_orientation;
  return true;
}

interfaces_mci__msg__NavTaskCoordsMci *
interfaces_mci__msg__NavTaskCoordsMci__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces_mci__msg__NavTaskCoordsMci * msg = (interfaces_mci__msg__NavTaskCoordsMci *)allocator.allocate(sizeof(interfaces_mci__msg__NavTaskCoordsMci), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(interfaces_mci__msg__NavTaskCoordsMci));
  bool success = interfaces_mci__msg__NavTaskCoordsMci__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
interfaces_mci__msg__NavTaskCoordsMci__destroy(interfaces_mci__msg__NavTaskCoordsMci * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    interfaces_mci__msg__NavTaskCoordsMci__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
interfaces_mci__msg__NavTaskCoordsMci__Sequence__init(interfaces_mci__msg__NavTaskCoordsMci__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces_mci__msg__NavTaskCoordsMci * data = NULL;

  if (size) {
    data = (interfaces_mci__msg__NavTaskCoordsMci *)allocator.zero_allocate(size, sizeof(interfaces_mci__msg__NavTaskCoordsMci), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = interfaces_mci__msg__NavTaskCoordsMci__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        interfaces_mci__msg__NavTaskCoordsMci__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
interfaces_mci__msg__NavTaskCoordsMci__Sequence__fini(interfaces_mci__msg__NavTaskCoordsMci__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      interfaces_mci__msg__NavTaskCoordsMci__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

interfaces_mci__msg__NavTaskCoordsMci__Sequence *
interfaces_mci__msg__NavTaskCoordsMci__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  interfaces_mci__msg__NavTaskCoordsMci__Sequence * array = (interfaces_mci__msg__NavTaskCoordsMci__Sequence *)allocator.allocate(sizeof(interfaces_mci__msg__NavTaskCoordsMci__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = interfaces_mci__msg__NavTaskCoordsMci__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
interfaces_mci__msg__NavTaskCoordsMci__Sequence__destroy(interfaces_mci__msg__NavTaskCoordsMci__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    interfaces_mci__msg__NavTaskCoordsMci__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
interfaces_mci__msg__NavTaskCoordsMci__Sequence__are_equal(const interfaces_mci__msg__NavTaskCoordsMci__Sequence * lhs, const interfaces_mci__msg__NavTaskCoordsMci__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!interfaces_mci__msg__NavTaskCoordsMci__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
interfaces_mci__msg__NavTaskCoordsMci__Sequence__copy(
  const interfaces_mci__msg__NavTaskCoordsMci__Sequence * input,
  interfaces_mci__msg__NavTaskCoordsMci__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(interfaces_mci__msg__NavTaskCoordsMci);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    interfaces_mci__msg__NavTaskCoordsMci * data =
      (interfaces_mci__msg__NavTaskCoordsMci *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!interfaces_mci__msg__NavTaskCoordsMci__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          interfaces_mci__msg__NavTaskCoordsMci__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!interfaces_mci__msg__NavTaskCoordsMci__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
