// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces_mci:msg/NavMci.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__DETAIL__NAV_MCI__STRUCT_H_
#define INTERFACES_MCI__MSG__DETAIL__NAV_MCI__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'goal_type'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/NavMci in the package interfaces_mci.
typedef struct interfaces_mci__msg__NavMci
{
  double x;
  double y;
  int64_t orientation;
  rosidl_runtime_c__String goal_type;
} interfaces_mci__msg__NavMci;

// Struct for a sequence of interfaces_mci__msg__NavMci.
typedef struct interfaces_mci__msg__NavMci__Sequence
{
  interfaces_mci__msg__NavMci * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces_mci__msg__NavMci__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES_MCI__MSG__DETAIL__NAV_MCI__STRUCT_H_
