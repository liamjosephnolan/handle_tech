// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES_MCI__MSG__NAV_TASK_COORDS_MCI_HPP_
#define INTERFACES_MCI__MSG__NAV_TASK_COORDS_MCI_HPP_

#include "interfaces_mci/msg/detail/nav_task_coords_mci__struct.hpp"
#include "interfaces_mci/msg/detail/nav_task_coords_mci__builder.hpp"
#include "interfaces_mci/msg/detail/nav_task_coords_mci__traits.hpp"

#endif  // INTERFACES_MCI__MSG__NAV_TASK_COORDS_MCI_HPP_
